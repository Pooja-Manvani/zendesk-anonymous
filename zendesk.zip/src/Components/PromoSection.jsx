import React from 'react'

export default function PromoSection() {
  return (
    <div className='promo-wrapper container' >PromoSection</div>
  )
}
